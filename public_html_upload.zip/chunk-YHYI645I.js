var t={production:!0,api_url:"https://premiatuidea.com/api",api_url_images:"https://premiatuidea.com"};export{t as a};
