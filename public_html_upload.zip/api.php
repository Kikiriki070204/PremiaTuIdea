<?php
use Illuminate\Contracts\Http\Kernel;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));
$laravelRoot = '/home/u516685076/domains/premiatuidea.com';

if (!file_exists($laravelRoot . '/vendor/autoload.php')) {
    http_response_code(500);
    die(json_encode(['error' => 'Laravel root not found at: ' . $laravelRoot]));
}

$authHeader = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? null;
if (!$authHeader) {
    foreach ($_SERVER as $k => $v) {
        if (stripos($k, 'AUTHORIZATION') !== false && !empty($v)) {
            $authHeader = $v; break;
        }
    }
}
if (!$authHeader && function_exists('getallheaders')) {
    foreach (getallheaders() as $k => $v) {
        if (strtolower($k) === 'authorization') { $authHeader = $v; break; }
    }
}
if ($authHeader) $_SERVER['HTTP_AUTHORIZATION'] = $authHeader;

foreach (['config.php','packages.php','services.php','routes-v7.php','events.php'] as $c) {
    $p = $laravelRoot . '/bootstrap/cache/' . $c;
    if (file_exists($p)) @unlink($p);
}

if (file_exists($m = $laravelRoot . '/storage/framework/maintenance.php')) require $m;

require $laravelRoot . '/vendor/autoload.php';
$app = require_once $laravelRoot . '/bootstrap/app.php';
$kernel = $app->make(Kernel::class);
$response = $kernel->handle($request = Request::capture());
$response->send();
$kernel->terminate($request, $response);
