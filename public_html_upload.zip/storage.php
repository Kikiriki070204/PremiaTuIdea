<?php
$s = '/home/u516685076/domains/premiatuidea.com/storage/app/public/';
$p = ltrim(preg_replace('#^/storage/#', '', strtok($_SERVER['REQUEST_URI'], '?')), '/');
$f = $s . $p;
if (file_exists($f) && is_file($f)) {
    header('Content-Type: ' . mime_content_type($f));
    header('Cache-Control: public, max-age=86400');
    readfile($f);
} else {
    http_response_code(404);
}
